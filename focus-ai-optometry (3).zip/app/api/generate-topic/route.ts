import { GoogleGenerativeAI } from "@google/generative-ai"

export async function POST(req: Request) {
  try {
    const { topic, level = "topic" } = await req.json()

    // Use the hardcoded API key if none is provided
    const apiKey = req.headers.get("x-gemini-api-key") || "AIzaSyB6RHAgIkXqpRaOAjm8i-U4YqLyHT5BmLE"
    const genAI = new GoogleGenerativeAI(apiKey)

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
    })

    // Adjust the prompt based on the level of content requested
    let prompt = ""

    if (level === "topic") {
      prompt = `Generate comprehensive educational content about the optometry topic: "${topic}".

Include the following sections:
1. Overview: A brief introduction to the topic
2. Key Concepts: The main principles or ideas related to the topic
3. Clinical Relevance: How this topic applies to optometric practice
4. Techniques or Procedures: Any specific methods related to this topic
5. Case Examples: Brief examples illustrating the topic in practice
6. Recent Developments: Current research or advances in this area
7. Study Questions: 3-5 questions to test understanding of the material

Format the content with clear headings, bullet points, and concise explanations. Make the content educational, accurate, and helpful for optometry students studying this topic.

Make sure to include relevant terminology, concepts, and clinical applications that would be covered in an optometry curriculum.`
    } else if (level === "unit") {
      prompt = `Generate a comprehensive unit overview for the optometry unit: "${topic}".

Include the following sections:
1. Unit Overview: A brief introduction to this unit and its place in the curriculum
2. Learning Objectives: What students should learn from this unit
3. Key Topics: The main topics covered in this unit with brief explanations
4. Clinical Applications: How the unit content applies to clinical practice
5. Study Resources: Recommended textbooks, journals, or online resources
6. Assessment Preparation: Tips for studying this unit effectively

Format the content with clear headings, bullet points, and concise explanations. Make the content educational, accurate, and helpful for optometry students studying this unit.

Make sure to include relevant terminology, concepts, and clinical applications that would be covered in this optometry unit.`
    } else if (level === "subject") {
      prompt = `Generate a comprehensive subject overview for the optometry subject: "${topic}".

Include the following sections:
1. Subject Introduction: What this subject covers and why it's important in optometry
2. Curriculum Structure: How this subject is typically structured in optometry programs
3. Key Units: The main units or modules typically included in this subject
4. Learning Outcomes: What students should achieve by studying this subject
5. Career Relevance: How this subject applies to optometric practice
6. Advanced Pathways: How this subject connects to advanced study or specialization
7. Study Strategies: Effective approaches to mastering this subject

Format the content with clear headings, bullet points, and concise explanations. Make the content educational, accurate, and helpful for optometry students.

Make sure to include relevant terminology, concepts, and clinical applications that would be covered in this optometry subject.`
    }

    const result = await model.generateContent(prompt)
    const text = result.response.text()

    // Clean up any remaining meta-text
    const cleanedText = text
      .replace(/^(I've generated|I have generated|Here's|Here is|I've created|I have created).*?\n/i, "")
      .replace(/^(Let me provide|Let's explore|I'll provide).*?\n/i, "")
      .replace(/^(Here are|The following is).*?\n/i, "")
      .trim()

    return Response.json({ content: cleanedText })
  } catch (error) {
    console.error("Error generating topic content:", error)
    const { topic } = await req.json() // Extract topic here for fallback

    return Response.json(
      {
        error: "Failed to generate topic content",
        content: `# ${topic}

## Overview
${topic} is an important topic in optometry that involves specific diagnostic and management approaches.

## Key Concepts
- Basic principles of ${topic}
- Clinical significance in optometry practice
- Diagnostic considerations

## Clinical Applications
- How ${topic} is applied in clinical settings
- Patient management considerations
- Best practices for assessment

## Summary
Understanding ${topic} is essential for comprehensive optometric care and patient management.`,
      },
      { status: 200 }, // Return 200 even for fallback to prevent cascading errors
    )
  }
}

