import { GoogleGenerativeAI } from "@google/generative-ai"
// Add authentication check to the API route
import { getCurrentUser, hasAIAccess } from "@/lib/auth"

export async function POST(req: Request) {
  try {
    // Check authentication
    const user = await getCurrentUser()
    if (!user || !hasAIAccess(user)) {
      return Response.json(
        {
          error: "Unauthorized",
          message: "You do not have access to this feature",
        },
        { status: 403 },
      )
    }

    const { topic } = await req.json()

    // Rest of the function remains the same

    try {
      // Use the Google Generative AI SDK with Gemini 2.0 Flash
      const apiKey =
        req.headers.get("x-gemini-api-key") || process.env.GEMINI_API_KEY || "AIzaSyB6RHAgIkXqpRaOAjm8i-U4YqLyHT5BmLE"
      const genAI = new GoogleGenerativeAI(apiKey)

      const model = genAI.getGenerativeModel({
        model: "gemini-2.0-flash",
      })

      const prompt = `Generate comprehensive educational content about the optometry topic: "${topic}".

Include the following sections:
1. Overview: A brief introduction to the topic
2. Key Concepts: The main principles or ideas related to the topic
3. Clinical Relevance: How this topic applies to optometric practice
4. Techniques or Procedures: Any specific methods related to this topic
5. Case Examples: Brief examples illustrating the topic in practice
6. Recent Developments: Current research or advances in this area
7. Study Questions: 3-5 questions to test understanding of the material

Format the content with clear headings, bullet points, and concise explanations. Make the content educational, accurate, and helpful for optometry students studying this topic.

Make sure to include relevant terminology, concepts, and clinical applications that would be covered in an optometry curriculum.

IMPORTANT: Do NOT include any meta-text like "I've generated this content" or "Here's information about". Start directly with the educational content.`

      const result = await model.generateContent(prompt)
      const text = result.response.text()

      // Clean up any remaining meta-text
      const cleanedText = text
        .replace(/^(I've generated|I have generated|Here's|Here is|I've created|I have created).*?\n/i, "")
        .replace(/^(Let me provide|Let's explore|I'll provide).*?\n/i, "")
        .replace(/^(Here are|The following is).*?\n/i, "")
        .trim()

      return Response.json({ content: cleanedText })
    } catch (error) {
      console.error("Error generating topic content:", error)
      return Response.json(
        {
          error: "Failed to generate topic content",
          content: `# ${topic}

## Overview
${topic} is an important topic in optometry that involves specific diagnostic and management approaches.

## Key Concepts
- Basic principles of ${topic}
- Clinical significance in optometry practice
- Diagnostic considerations

## Clinical Applications
- How ${topic} is applied in clinical settings
- Patient management considerations
- Best practices for assessment

## Summary
Understanding ${topic} is essential for comprehensive optometric care and patient management.`,
        },
        { status: 200 }, // Return 200 even for fallback to prevent cascading errors
      )
    }
  } catch (error) {
    console.error("Authentication error:", error)
    return Response.json({ error: "Internal Server Error" }, { status: 500 })
  }
}

