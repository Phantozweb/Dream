"use client"

import { StudyTools } from "@/components/study-tools"
import { DashboardStats } from "@/components/dashboard-stats"
import { RecentActivity } from "@/components/recent-activity"
import { StudyRecommendations } from "@/components/study-recommendations"

export default function Home() {
  return (
    <main className="container mx-auto p-4 md:p-6 space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Welcome to Focus.AI</h1>
        <p className="text-muted-foreground">Your AI-powered learning companion for optometry studies</p>
      </div>

      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <StudyTools />
          <RecentActivity />
        </div>
        <div className="space-y-6">
          <StudyRecommendations />
        </div>
      </div>
    </main>
  )
}

