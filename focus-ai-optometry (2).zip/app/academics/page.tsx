"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Search, ArrowLeft, BookOpen, Plus, Loader2, Download, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRef } from "react"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { Badge } from "@/components/ui/badge"

export default function AcademicsPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedYear, setSelectedYear] = useState("1")
  const [selectedSemester, setSelectedSemester] = useState("1")
  const [selectedUniversity, setSelectedUniversity] = useState("alagappa")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedContent, setGeneratedContent] = useState("")
  const [currentTopic, setCurrentTopic] = useState("")
  const contentRef = useRef<HTMLDivElement>(null)
  const [showFilters, setShowFilters] = useState(false)

  // Alagappa University curriculum data structure
  const alagappaUniversityCurriculum = {
    "1": {
      "1": [
        {
          id: "CC-91413",
          title: "General Anatomy & Physiology",
          progress: 70,
          units: [
            {
              title: "Unit 1: Introduction to Human Anatomy",
              topics: [
                { id: "1.1", title: "Anatomical Terminology", completed: true },
                { id: "1.2", title: "Body Systems Overview", completed: true },
                { id: "1.3", title: "Cellular Structure and Function", completed: false },
              ],
            },
            {
              title: "Unit 2: Human Physiology Basics",
              topics: [
                { id: "2.1", title: "Homeostasis", completed: true },
                { id: "2.2", title: "Nervous System Physiology", completed: false },
                { id: "2.3", title: "Cardiovascular Physiology", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91414",
          title: "Geometrical Optics",
          progress: 65,
          units: [
            {
              title: "Unit 1: Reflection and Refraction",
              topics: [
                { id: "1.1", title: "Laws of Reflection", completed: true },
                { id: "1.2", title: "Snell's Law", completed: true },
                { id: "1.3", title: "Total Internal Reflection", completed: false },
              ],
            },
            {
              title: "Unit 2: Lenses and Mirrors",
              topics: [
                { id: "2.1", title: "Spherical Mirrors", completed: true },
                { id: "2.2", title: "Thin Lenses", completed: false },
                { id: "2.3", title: "Lens Combinations", completed: false },
              ],
            },
          ],
        },
      ],
      "2": [
        {
          id: "CC-91423",
          title: "Ocular Anatomy",
          progress: 60,
          units: [
            {
              title: "Unit 1: External Ocular Structures",
              topics: [
                { id: "1.1", title: "Eyelids and Adnexa", completed: true },
                { id: "1.2", title: "Lacrimal System", completed: true },
                { id: "1.3", title: "Extraocular Muscles", completed: false },
              ],
            },
            {
              title: "Unit 2: Anterior Segment",
              topics: [
                { id: "2.1", title: "Cornea", completed: true },
                { id: "2.2", title: "Anterior Chamber", completed: false },
                { id: "2.3", title: "Iris and Pupil", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91424",
          title: "Ocular Physiology",
          progress: 55,
          units: [
            {
              title: "Unit 1: Tear Film Physiology",
              topics: [
                { id: "1.1", title: "Tear Film Structure", completed: true },
                { id: "1.2", title: "Tear Production and Drainage", completed: false },
                { id: "1.3", title: "Tear Film Dysfunction", completed: false },
              ],
            },
            {
              title: "Unit 2: Aqueous Humor Dynamics",
              topics: [
                { id: "2.1", title: "Aqueous Production", completed: true },
                { id: "2.2", title: "Outflow Pathways", completed: false },
                { id: "2.3", title: "Intraocular Pressure Regulation", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91425",
          title: "Physical Optics",
          progress: 50,
          units: [
            {
              title: "Unit 1: Wave Optics",
              topics: [
                { id: "1.1", title: "Wave Nature of Light", completed: true },
                { id: "1.2", title: "Interference", completed: false },
                { id: "1.3", title: "Diffraction", completed: false },
              ],
            },
            {
              title: "Unit 2: Polarization",
              topics: [
                { id: "2.1", title: "Polarization Principles", completed: true },
                { id: "2.2", title: "Polarizers and Analyzers", completed: false },
                { id: "2.3", title: "Applications in Optometry", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91426",
          title: "Practical – Physical & Geometrical Optics",
          progress: 45,
          units: [
            {
              title: "Unit 1: Geometrical Optics Experiments",
              topics: [
                { id: "1.1", title: "Focal Length Determination", completed: true },
                { id: "1.2", title: "Lens Power Measurement", completed: false },
                { id: "1.3", title: "Prism Experiments", completed: false },
              ],
            },
            {
              title: "Unit 2: Physical Optics Experiments",
              topics: [
                { id: "2.1", title: "Interference Patterns", completed: false },
                { id: "2.2", title: "Diffraction Experiments", completed: false },
                { id: "2.3", title: "Polarization Measurements", completed: false },
              ],
            },
          ],
        },
      ],
    },
    "2": {
      "1": [
        {
          id: "CC-91433",
          title: "Visual Optics",
          progress: 40,
          units: [
            {
              title: "Unit 1: Optical System of the Eye",
              topics: [
                { id: "1.1", title: "Schematic Eye Models", completed: true },
                { id: "1.2", title: "Refractive Errors", completed: false },
                { id: "1.3", title: "Accommodation", completed: false },
              ],
            },
            {
              title: "Unit 2: Retinal Image Formation",
              topics: [
                { id: "2.1", title: "Image Quality Metrics", completed: false },
                { id: "2.2", title: "Aberrations", completed: false },
                { id: "2.3", title: "Depth of Focus", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91434",
          title: "Optometric Optics",
          progress: 35,
          units: [
            {
              title: "Unit 1: Ophthalmic Lenses",
              topics: [
                { id: "1.1", title: "Lens Types and Materials", completed: true },
                { id: "1.2", title: "Lens Design", completed: false },
                { id: "1.3", title: "Lens Verification", completed: false },
              ],
            },
            {
              title: "Unit 2: Prisms and Prismatic Effects",
              topics: [
                { id: "2.1", title: "Prism Notation", completed: false },
                { id: "2.2", title: "Prismatic Effects of Lenses", completed: false },
                { id: "2.3", title: "Prescribing Prisms", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91435",
          title: "Ocular Diseases – I",
          progress: 30,
          units: [
            {
              title: "Unit 1: Anterior Segment Disorders",
              topics: [
                { id: "1.1", title: "Conjunctival Disorders", completed: true },
                { id: "1.2", title: "Corneal Diseases", completed: false },
                { id: "1.3", title: "Eyelid Conditions", completed: false },
              ],
            },
            {
              title: "Unit 2: Lens Disorders",
              topics: [
                { id: "2.1", title: "Cataracts", completed: false },
                { id: "2.2", title: "Lens Anomalies", completed: false },
                { id: "2.3", title: "Surgical Management", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91436",
          title: "Practical – Visual & Optometric Optics",
          progress: 25,
          units: [
            {
              title: "Unit 1: Visual Optics Experiments",
              topics: [
                { id: "1.1", title: "Keratometry", completed: true },
                { id: "1.2", title: "Accommodation Assessment", completed: false },
                { id: "1.3", title: "Pupillometry", completed: false },
              ],
            },
            {
              title: "Unit 2: Optometric Optics Practicals",
              topics: [
                { id: "2.1", title: "Lens Neutralization", completed: false },
                { id: "2.2", title: "Lens Thickness Measurement", completed: false },
                { id: "2.3", title: "Prism Verification", completed: false },
              ],
            },
          ],
        },
      ],
      "2": [
        {
          id: "CC-91443",
          title: "Optometric Instrumentation & Clinical Examinations of the Visual System (CEVS)",
          progress: 20,
          units: [
            {
              title: "Unit 1: Basic Optometric Instruments",
              topics: [
                { id: "1.1", title: "Retinoscope", completed: true },
                { id: "1.2", title: "Ophthalmoscope", completed: false },
                { id: "1.3", title: "Slit Lamp", completed: false },
              ],
            },
            {
              title: "Unit 2: Clinical Examination Procedures",
              topics: [
                { id: "2.1", title: "Visual Acuity Assessment", completed: false },
                { id: "2.2", title: "Refraction Techniques", completed: false },
                { id: "2.3", title: "Binocular Vision Tests", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91444",
          title: "Ocular Diseases – II",
          progress: 15,
          units: [
            {
              title: "Unit 1: Posterior Segment Disorders",
              topics: [
                { id: "1.1", title: "Retinal Diseases", completed: false },
                { id: "1.2", title: "Optic Nerve Disorders", completed: false },
                { id: "1.3", title: "Choroidal Conditions", completed: false },
              ],
            },
            {
              title: "Unit 2: Glaucoma",
              topics: [
                { id: "2.1", title: "Primary Glaucomas", completed: false },
                { id: "2.2", title: "Secondary Glaucomas", completed: false },
                { id: "2.3", title: "Glaucoma Management", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91445",
          title: "Practical- Instrumentation & CEVS",
          progress: 10,
          units: [
            {
              title: "Unit 1: Instrument Handling",
              topics: [
                { id: "1.1", title: "Retinoscopy Practice", completed: false },
                { id: "1.2", title: "Slit Lamp Examination", completed: false },
                { id: "1.3", title: "Ophthalmoscopy", completed: false },
              ],
            },
            {
              title: "Unit 2: Clinical Procedures",
              topics: [
                { id: "2.1", title: "Refraction Practice", completed: false },
                { id: "2.2", title: "Tonometry", completed: false },
                { id: "2.3", title: "Visual Field Assessment", completed: false },
              ],
            },
          ],
        },
      ],
    },
    "3": {
      "1": [
        {
          id: "CC-91451",
          title: "Contact Lens – I",
          progress: 5,
          units: [
            {
              title: "Unit 1: Contact Lens Basics",
              topics: [
                { id: "1.1", title: "Contact Lens Materials", completed: false },
                { id: "1.2", title: "Lens Designs", completed: false },
                { id: "1.3", title: "Fitting Philosophy", completed: false },
              ],
            },
            {
              title: "Unit 2: Soft Contact Lenses",
              topics: [
                { id: "2.1", title: "Soft Lens Parameters", completed: false },
                { id: "2.2", title: "Fitting Assessment", completed: false },
                { id: "2.3", title: "Care Systems", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91452",
          title: "Binocular Vision - I",
          progress: 5,
          units: [
            {
              title: "Unit 1: Normal Binocular Vision",
              topics: [
                { id: "1.1", title: "Sensory Fusion", completed: false },
                { id: "1.2", title: "Motor Fusion", completed: false },
                { id: "1.3", title: "Stereopsis", completed: false },
              ],
            },
            {
              title: "Unit 2: Binocular Vision Assessment",
              topics: [
                { id: "2.1", title: "Cover Tests", completed: false },
                { id: "2.2", title: "Fusional Vergence", completed: false },
                { id: "2.3", title: "Fixation Disparity", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91453",
          title: "Pediatric & Geriatric Optometry",
          progress: 5,
          units: [
            {
              title: "Unit 1: Pediatric Optometry",
              topics: [
                { id: "1.1", title: "Visual Development", completed: false },
                { id: "1.2", title: "Pediatric Examination", completed: false },
                { id: "1.3", title: "Amblyopia Management", completed: false },
              ],
            },
            {
              title: "Unit 2: Geriatric Optometry",
              topics: [
                { id: "2.1", title: "Age-related Visual Changes", completed: false },
                { id: "2.2", title: "Geriatric Examination", completed: false },
                { id: "2.3", title: "Low Vision in Elderly", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91454",
          title: "Dispensing Optics",
          progress: 5,
          units: [
            {
              title: "Unit 1: Frame Selection and Fitting",
              topics: [
                { id: "1.1", title: "Frame Materials", completed: false },
                { id: "1.2", title: "Frame Measurements", completed: false },
                { id: "1.3", title: "Adjustments", completed: false },
              ],
            },
            {
              title: "Unit 2: Lens Dispensing",
              topics: [
                { id: "2.1", title: "Lens Verification", completed: false },
                { id: "2.2", title: "Troubleshooting", completed: false },
                { id: "2.3", title: "Patient Education", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91455",
          title: "Practical – Clinical Optometry - I",
          progress: 5,
          units: [
            {
              title: "Unit 1: Clinical Procedures",
              topics: [
                { id: "1.1", title: "Case History", completed: false },
                { id: "1.2", title: "Preliminary Tests", completed: false },
                { id: "1.3", title: "Refraction", completed: false },
              ],
            },
            {
              title: "Unit 2: Special Tests",
              topics: [
                { id: "2.1", title: "Color Vision", completed: false },
                { id: "2.2", title: "Contrast Sensitivity", completed: false },
                { id: "2.3", title: "Binocular Vision Tests", completed: false },
              ],
            },
          ],
        },
      ],
      "2": [
        {
          id: "CC-91461",
          title: "Contact Lens – II",
          progress: 0,
          units: [
            {
              title: "Unit 1: Rigid Gas Permeable Lenses",
              topics: [
                { id: "1.1", title: "RGP Materials", completed: false },
                { id: "1.2", title: "Fitting Techniques", completed: false },
                { id: "1.3", title: "Problem Solving", completed: false },
              ],
            },
            {
              title: "Unit 2: Specialty Contact Lenses",
              topics: [
                { id: "2.1", title: "Toric Lenses", completed: false },
                { id: "2.2", title: "Multifocal Designs", completed: false },
                { id: "2.3", title: "Therapeutic Lenses", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91462",
          title: "Binocular Vision - II",
          progress: 0,
          units: [
            {
              title: "Unit 1: Binocular Vision Anomalies",
              topics: [
                { id: "1.1", title: "Heterophoria", completed: false },
                { id: "1.2", title: "Convergence Insufficiency", completed: false },
                { id: "1.3", title: "Accommodative Disorders", completed: false },
              ],
            },
            {
              title: "Unit 2: Strabismus",
              topics: [
                { id: "2.1", title: "Esotropia", completed: false },
                { id: "2.2", title: "Exotropia", completed: false },
                { id: "2.3", title: "Management Approaches", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91463",
          title: "Low Vision Aids",
          progress: 0,
          units: [
            {
              title: "Unit 1: Low Vision Assessment",
              topics: [
                { id: "1.1", title: "Visual Function Evaluation", completed: false },
                { id: "1.2", title: "Functional Vision Assessment", completed: false },
                { id: "1.3", title: "Goal Setting", completed: false },
              ],
            },
            {
              title: "Unit 2: Low Vision Devices",
              topics: [
                { id: "2.1", title: "Optical Devices", completed: false },
                { id: "2.2", title: "Non-optical Devices", completed: false },
                { id: "2.3", title: "Electronic Magnification", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91464",
          title: "Practical – Clinical Optometry - II",
          progress: 0,
          units: [
            {
              title: "Unit 1: Advanced Clinical Procedures",
              topics: [
                { id: "1.1", title: "Anterior Segment Evaluation", completed: false },
                { id: "1.2", title: "Posterior Segment Evaluation", completed: false },
                { id: "1.3", title: "Gonioscopy", completed: false },
              ],
            },
            {
              title: "Unit 2: Specialty Testing",
              topics: [
                { id: "2.1", title: "Visual Field Assessment", completed: false },
                { id: "2.2", title: "Electrophysiology", completed: false },
                { id: "2.3", title: "Imaging Techniques", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91465",
          title: "Systemic Diseases Affecting the Eye",
          progress: 0,
          units: [
            {
              title: "Unit 1: Vascular Diseases",
              topics: [
                { id: "1.1", title: "Diabetes Mellitus", completed: false },
                { id: "1.2", title: "Hypertension", completed: false },
                { id: "1.3", title: "Cardiovascular Disorders", completed: false },
              ],
            },
            {
              title: "Unit 2: Other Systemic Conditions",
              topics: [
                { id: "2.1", title: "Autoimmune Disorders", completed: false },
                { id: "2.2", title: "Neurological Diseases", completed: false },
                { id: "2.3", title: "Endocrine Disorders", completed: false },
              ],
            },
          ],
        },
      ],
    },
    "4": {
      "1": [
        {
          id: "CC-91471",
          title: "Internship - I",
          progress: 0,
          units: [
            {
              title: "Unit 1: Clinical Rotations",
              topics: [
                { id: "1.1", title: "Primary Care", completed: false },
                { id: "1.2", title: "Contact Lens Clinic", completed: false },
                { id: "1.3", title: "Pediatric Clinic", completed: false },
              ],
            },
            {
              title: "Unit 2: Clinical Skills",
              topics: [
                { id: "2.1", title: "Case Management", completed: false },
                { id: "2.2", title: "Clinical Decision Making", completed: false },
                { id: "2.3", title: "Patient Communication", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91472",
          title: "Project - I",
          progress: 0,
          units: [
            {
              title: "Unit 1: Research Methodology",
              topics: [
                { id: "1.1", title: "Literature Review", completed: false },
                { id: "1.2", title: "Research Design", completed: false },
                { id: "1.3", title: "Data Collection Methods", completed: false },
              ],
            },
            {
              title: "Unit 2: Project Planning",
              topics: [
                { id: "2.1", title: "Topic Selection", completed: false },
                { id: "2.2", title: "Proposal Development", completed: false },
                { id: "2.3", title: "Ethics Approval", completed: false },
              ],
            },
          ],
        },
      ],
      "2": [
        {
          id: "CC-91481",
          title: "Internship - II",
          progress: 0,
          units: [
            {
              title: "Unit 1: Advanced Clinical Rotations",
              topics: [
                { id: "1.1", title: "Specialty Clinics", completed: false },
                { id: "1.2", title: "Hospital Rotations", completed: false },
                { id: "1.3", title: "Community Outreach", completed: false },
              ],
            },
            {
              title: "Unit 2: Professional Development",
              topics: [
                { id: "2.1", title: "Clinical Protocols", completed: false },
                { id: "2.2", title: "Practice Management", completed: false },
                { id: "2.3", title: "Ethical Considerations", completed: false },
              ],
            },
          ],
        },
        {
          id: "CC-91482",
          title: "Project - II",
          progress: 0,
          units: [
            {
              title: "Unit 1: Data Analysis",
              topics: [
                { id: "1.1", title: "Statistical Methods", completed: false },
                { id: "1.2", title: "Results Interpretation", completed: false },
                { id: "1.3", title: "Discussion Development", completed: false },
              ],
            },
            {
              title: "Unit 2: Project Completion",
              topics: [
                { id: "2.1", title: "Thesis Writing", completed: false },
                { id: "2.2", title: "Presentation Preparation", completed: false },
                { id: "2.3", title: "Defense", completed: false },
              ],
            },
          ],
        },
      ],
    },
  }

  // Original curriculum data structure (renamed to genericCurriculum)
  const genericCurriculum = {
    "1": {
      "1": [
        {
          id: "OPT101",
          title: "Introduction to Optometry",
          progress: 85,
          units: [
            {
              title: "Unit 1: History and Scope of Optometry",
              topics: [
                { id: "1.1", title: "Evolution of Optometry as a Profession", completed: true },
                { id: "1.2", title: "Scope of Practice and Legal Regulations", completed: true },
                { id: "1.3", title: "Optometry Education and Specializations", completed: false },
              ],
            },
            {
              title: "Unit 2: Optometric Examination Basics",
              topics: [
                { id: "2.1", title: "Patient History and Communication", completed: true },
                { id: "2.2", title: "Preliminary Testing Procedures", completed: true },
                { id: "2.3", title: "Documentation and Record Keeping", completed: true },
              ],
            },
          ],
        },
        {
          id: "OPT102",
          title: "Ocular Anatomy and Physiology I",
          progress: 70,
          units: [
            {
              title: "Unit 1: External Ocular Structures",
              topics: [
                { id: "1.1", title: "Eyelids and Lacrimal System", completed: true },
                { id: "1.2", title: "Conjunctiva and Sclera", completed: true },
                { id: "1.3", title: "Cornea: Structure and Function", completed: false },
              ],
            },
            {
              title: "Unit 2: Anterior Segment",
              topics: [
                { id: "2.1", title: "Anterior Chamber and Angle", completed: true },
                { id: "2.2", title: "Iris and Pupil", completed: true },
                { id: "2.3", title: "Crystalline Lens", completed: false },
              ],
            },
          ],
        },
        {
          id: "OPT103",
          title: "Geometric and Physical Optics",
          progress: 60,
          units: [
            {
              title: "Unit 1: Principles of Light",
              topics: [
                { id: "1.1", title: "Nature of Light and Electromagnetic Spectrum", completed: true },
                { id: "1.2", title: "Reflection and Refraction", completed: true },
                { id: "1.3", title: "Dispersion and Absorption", completed: false },
              ],
            },
            {
              title: "Unit 2: Optical Systems",
              topics: [
                { id: "2.1", title: "Lenses and Prisms", completed: true },
                { id: "2.2", title: "Mirrors and Aberrations", completed: false },
                { id: "2.3", title: "Optical Instruments", completed: false },
              ],
            },
          ],
        },
      ],
      "2": [
        {
          id: "OPT201",
          title: "Ocular Anatomy and Physiology II",
          progress: 40,
          units: [
            {
              title: "Unit 1: Posterior Segment",
              topics: [
                { id: "1.1", title: "Vitreous Humor", completed: true },
                { id: "1.2", title: "Retina: Structure and Function", completed: false },
                { id: "1.3", title: "Optic Nerve and Visual Pathway", completed: false },
              ],
            },
          ],
        },
      ],
    },
    "2": {
      "1": [
        {
          id: "OPT301",
          title: "Clinical Procedures I",
          progress: 30,
          units: [
            {
              title: "Unit 1: Refraction Techniques",
              topics: [
                { id: "1.1", title: "Retinoscopy", completed: true },
                { id: "1.2", title: "Subjective Refraction", completed: false },
                { id: "1.3", title: "Binocular Balance", completed: false },
              ],
            },
          ],
        },
      ],
    },
  }

  // Function to get the appropriate curriculum based on selected university
  const getCurriculum = () => {
    switch (selectedUniversity) {
      case "alagappa":
        return alagappaUniversityCurriculum
      default:
        return genericCurriculum
    }
  }

  const handleTopicClick = async (topicTitle: string) => {
    setCurrentTopic(topicTitle)
    setIsGenerating(true)
    setGeneratedContent("")

    try {
      // Call the API to generate content for the topic
      const response = await fetch("/api/generate-topic", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-gemini-api-key": localStorage.getItem("gemini_api_key") || "AIzaSyB6RHAgIkXqpRaOAjm8i-U4YqLyHT5BmLE",
        },
        body: JSON.stringify({ topic: topicTitle }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate topic content")
      }

      const data = await response.json()
      setGeneratedContent(data.content)
    } catch (error) {
      console.error("Error generating topic content:", error)
      toast({
        title: "Error",
        description: "Failed to generate topic content. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleTopicToggle = (topicId: string, completed: boolean) => {
    // In a real app, this would update the database
    console.log(`Topic ${topicId} marked as ${completed ? "completed" : "incomplete"}`)

    toast({
      title: completed ? "Topic Completed" : "Topic Marked as Incomplete",
      description: `Your progress has been updated.`,
    })
  }

  // Filter subjects based on selected year and semester
  const filteredSubjects = getCurriculum()[selectedYear]?.[selectedSemester] || []

  // Filter subjects based on search query (now includes subject code search)
  const searchedSubjects = searchQuery
    ? filteredSubjects.filter(
        (subject) =>
          subject.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          subject.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          subject.units.some(
            (unit) =>
              unit.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              unit.topics.some((topic) => topic.title.toLowerCase().includes(searchQuery.toLowerCase())),
          ),
      )
    : filteredSubjects

  // Add function to download content as PDF
  const downloadAsPDF = async () => {
    if (!contentRef.current || !currentTopic) return

    toast({
      title: "Generating PDF",
      description: "Please wait while we prepare your PDF...",
    })

    try {
      // Create a canvas from the content
      const canvas = await html2canvas(contentRef.current, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
      })

      // Create PDF
      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      })

      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      // Add image to PDF with proper pagination
      let heightLeft = imgHeight
      let position = 0
      const pageData = imgData

      // First page
      pdf.addImage(pageData, "PNG", 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      // Add subsequent pages
      while (heightLeft > 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(pageData, "PNG", 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      // Save PDF
      pdf.save(`${currentTopic.replace(/[^a-z0-9]/gi, "_")}.pdf`)

      toast({
        title: "PDF Downloaded",
        description: "Your content has been downloaded as a PDF file.",
      })
    } catch (error) {
      console.error("Error generating PDF:", error)
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" asChild className="h-8 w-8">
            <Link href="/">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back to Dashboard</span>
            </Link>
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Optometry Academics</h1>
        </div>
        <p className="text-muted-foreground">Browse the curriculum, track your progress, and manage your studies</p>

        <Tabs defaultValue="curriculum">
          <TabsList>
            <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
            <TabsTrigger value="topic" disabled={!currentTopic}>
              Topic Content
            </TabsTrigger>
          </TabsList>

          <TabsContent value="curriculum" className="mt-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle>Filter Syllabus</CardTitle>
                      <Button variant="ghost" size="sm" onClick={() => setShowFilters(!showFilters)}>
                        <Filter className="h-4 w-4 mr-2" />
                        {showFilters ? "Hide Filters" : "Show Filters"}
                      </Button>
                    </div>
                    <CardDescription>Select university, year and semester to view subjects</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="university">University</Label>
                      <Select value={selectedUniversity} onValueChange={setSelectedUniversity}>
                        <SelectTrigger id="university">
                          <SelectValue placeholder="Select university" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="alagappa">Alagappa University, Karaikudi</SelectItem>
                          <SelectItem value="generic">Generic Curriculum</SelectItem>
                        </SelectContent>
                      </Select>
                      {selectedUniversity === "alagappa" && (
                        <Badge variant="outline" className="mt-1">
                          Alagappa University, Karaikudi, Tamil Nadu
                        </Badge>
                      )}
                    </div>

                    {showFilters && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="year">Year</Label>
                          <Select value={selectedYear} onValueChange={setSelectedYear}>
                            <SelectTrigger id="year">
                              <SelectValue placeholder="Select year" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">Year 1</SelectItem>
                              <SelectItem value="2">Year 2</SelectItem>
                              <SelectItem value="3">Year 3</SelectItem>
                              <SelectItem value="4">Year 4</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="semester">Semester</Label>
                          <Select value={selectedSemester} onValueChange={setSelectedSemester}>
                            <SelectTrigger id="semester">
                              <SelectValue placeholder="Select semester" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">Semester 1</SelectItem>
                              <SelectItem value="2">Semester 2</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="search">Search by Subject Code or Title</Label>
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="search"
                          placeholder="e.g., CC-91413 or Ocular Anatomy..."
                          className="pl-8"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Overall Progress</CardTitle>
                    <CardDescription>Your progress through the curriculum</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Year 1</span>
                        <span className="text-sm text-muted-foreground">75%</span>
                      </div>
                      <Progress value={75} />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Year 2</span>
                        <span className="text-sm text-muted-foreground">30%</span>
                      </div>
                      <Progress value={30} />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Year 3</span>
                        <span className="text-sm text-muted-foreground">10%</span>
                      </div>
                      <Progress value={10} />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Year 4</span>
                        <span className="text-sm text-muted-foreground">0%</span>
                      </div>
                      <Progress value={0} />
                    </div>

                    <div className="pt-2 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Total Curriculum</span>
                        <span className="text-sm text-muted-foreground">26%</span>
                      </div>
                      <Progress value={26} className="mt-2" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2">
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>
                      {selectedUniversity === "alagappa" ? "Alagappa University" : "Generic Curriculum"}: Year{" "}
                      {selectedYear}, Semester {selectedSemester} Subjects
                    </CardTitle>
                    <CardDescription>{searchedSubjects.length} subjects found</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[calc(100vh-300px)] overflow-y-auto">
                    {searchedSubjects.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center p-4">
                        <Search className="h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium">No subjects found</h3>
                        <p className="text-sm text-muted-foreground mt-1">Try adjusting your search or filters</p>
                      </div>
                    ) : (
                      <Accordion type="multiple" className="space-y-4">
                        {searchedSubjects.map((subject) => (
                          <AccordionItem key={subject.id} value={subject.id} className="border rounded-lg px-2">
                            <AccordionTrigger className="hover:no-underline py-4">
                              <div className="flex flex-col items-start text-left">
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className="font-mono">
                                    {subject.id}
                                  </Badge>
                                  <span className="text-base font-semibold">{subject.title}</span>
                                </div>
                                <div className="w-full mt-2">
                                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                                    <span>Progress</span>
                                    <span>{subject.progress}%</span>
                                  </div>
                                  <Progress value={subject.progress} className="h-2" />
                                </div>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-4 py-2">
                                {subject.units.map((unit, unitIndex) => (
                                  <div key={unitIndex} className="space-y-2">
                                    <h4 className="font-medium text-sm">{unit.title}</h4>
                                    <div className="space-y-2 ml-4">
                                      {unit.topics.map((topic) => (
                                        <div key={topic.id} className="flex items-center space-x-2">
                                          <Checkbox
                                            id={`topic-${topic.id}`}
                                            checked={topic.completed}
                                            onCheckedChange={(checked) =>
                                              handleTopicToggle(topic.id, checked as boolean)
                                            }
                                          />
                                          <Label
                                            htmlFor={`topic-${topic.id}`}
                                            className={`text-sm ${topic.completed ? "line-through text-muted-foreground" : ""}`}
                                          >
                                            {topic.title}
                                          </Label>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-6 w-6 ml-auto"
                                            onClick={() => handleTopicClick(topic.title)}
                                          >
                                            <Plus className="h-4 w-4" />
                                          </Button>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                                <div className="pt-2">
                                  <Button variant="outline" size="sm" className="w-full">
                                    <BookOpen className="h-4 w-4 mr-2" />
                                    View Detailed Content
                                  </Button>
                                </div>
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="topic" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{currentTopic}</CardTitle>
                    <CardDescription>Educational content for this topic</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={downloadAsPDF}>
                      <Download className="h-4 w-4 mr-2" />
                      Download PDF
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => document.querySelector('[data-value="curriculum"]')?.click()}
                    >
                      Back to Curriculum
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isGenerating ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
                    <p className="text-muted-foreground">Generating content for {currentTopic}...</p>
                  </div>
                ) : (
                  <div className="prose prose-sm dark:prose-invert max-w-none" ref={contentRef}>
                    {generatedContent ? (
                      <div dangerouslySetInnerHTML={{ __html: generatedContent.replace(/\n/g, "<br />") }} />
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground">No content generated yet. Please select a topic.</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

