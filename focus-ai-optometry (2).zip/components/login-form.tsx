"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Eye, EyeOff, Loader2 } from "lucide-react"
import { authenticateUser } from "@/lib/auth"
import { useAuth } from "@/components/auth-provider"
import { Badge } from "@/components/ui/badge"

export function LoginForm() {
  const { toast } = useToast()
  const { login } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const user = authenticateUser(email, password)

      if (user) {
        login(user)
        toast({
          title: "Login successful",
          description: `Welcome back, ${user.name}!`,
        })
      } else {
        toast({
          title: "Login failed",
          description: "Invalid email or password. Please try again or use one of the demo accounts below.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Login to Focus.AI</CardTitle>
        <CardDescription>Enter your credentials to access your account</CardDescription>
      </CardHeader>
      <form onSubmit={handleLogin}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full px-3"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
              </Button>
            </div>
          </div>
          <div className="bg-muted/50 p-3 rounded-md mt-4">
            <p className="text-sm font-medium mb-2">Demo Accounts:</p>
            <div className="grid grid-cols-1 gap-2 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <Badge
                    variant="outline"
                    className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-blue-500/50 mr-2"
                  >
                    Premium
                  </Badge>
                  <span className="font-medium">premium@optometry.edu</span>
                </div>
                <span className="text-muted-foreground">premium123</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Badge
                    variant="outline"
                    className="bg-green-500/20 text-green-700 dark:text-green-400 border-green-500/50 mr-2"
                  >
                    Beta
                  </Badge>
                  <span className="font-medium">beta@optometry.edu</span>
                </div>
                <span className="text-muted-foreground">beta123</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Badge
                    variant="outline"
                    className="bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 border-yellow-500/50 mr-2"
                  >
                    Free
                  </Badge>
                  <span className="font-medium">student@optometry.edu</span>
                </div>
                <span className="text-muted-foreground">student123</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Logging in...
              </>
            ) : (
              "Login"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

